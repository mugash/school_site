   <?php
require 'header.php';
 ?>
  <!--  <link rel="stylesheet" type="text/css" href="http://getbootstrap.com.vn/examples/equal-height-columns/equal-height-columns.css"> -->
    <style type="text/css">
      .cont {
        padding-top: 150px;
        background-color: #eee;
      }
        .myimg {
          width: 100%;
        }
      
    </style>
    <div class="container cont">
    
    <div class="row">
  <div class="col-xs-12 col-sm-12 col-md-8 col-lg-8">
  <h2 class="h2">FROM THE SCIENCE DEPARTMENT</h2>
  <hr>
   <div class="para1">
  <p>The department comprises of chemistry, physics and biology. There are 13 members of staff and 3 lab technicians.
</p>
</div>
<div class="para2">
  <p>Performance has been good and we expect better results in future. Most students take 3 science subjects at form 3 and 4 with few taking two science subjects.
     </p>
   </div>
   <div class="para3">
     <p>
       Students have a positive attitude towards sciences and this has contributed to good results. A lot of practicals are done in sciences in all class to reinforce the scientific concepts. More practicals are given to form 4s btn 4pm and 5pm to thoroughly prepare them for KCSE
            </p>
            <p>
            Teachers have sacrificed time to encourage and assist students at subject level in the department. They have also incorporated the concepts acquired during SMASE inset trainings which have improved the attitude and performance of sciences.
            </p>
            <p>
            The administration has fully supported the department in terms of provision of materials and apparatus for practicals lab technicians – Mr. Maingi, Mr. Maimbo and Mr. Nzioka have prepared well and on time.
            </p>
            <p>
            As we focus to achieve our 2014 target of 10.5 the science department is working together as a team and through the will and grace of God we will harvest what have sown.
            <p>
          </div>
  </div>
  <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
     <a href="#" class="thumbnail">
      <img src="http://www.princehenrys.worcs.sch.uk/wp-content/uploads/2012/10/20130917-Year-9-Maths-Triptych-3-1.jpg" alt="boarding department head" class="img-thumbnail img-responsive">
      <div class="caption">
        <h3>From the department</h3>
        <p>The science department struggle to excel</p>
        </div>
    </a>
  </div>
</div>
</div>
    <?php
    require 'footer.php';
     ?>
    </body>
    </html>