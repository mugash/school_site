<?php
require 'header.php';
 ?>
 <div class="container text-center">
<div class="jumbotron">
<h2 class="h2 text-center">TENDERS</h2>
    <hr class="star-primary">
    <ul class="list-group">
   <a href="view_tenders.php"><li class="list-group-item">
  Spring 2017 term begin</a>
 <h4><small>January 17 2017 - January 30 2017</small></h4>
  </li>
  
  <a href="#"><li class="list-group-item">Drama festival coming up</a><h4><small>January 17 2016 - February 18 2016</small></h4></li>
  <a href="#"><li class="list-group-item">feast of St.Ignatius of Loyola</a><h4><small>January 17 2016 - February 18 2016</small></h4></li>
  <a href="#"><li class="list-group-item">Annual general meeting comming up</a><h4><small>January 17 2016 - February 18 2016</small></h4></li>
  <a href="#"><li class="list-group-item">Annual general meeting comming up</a><h4><small>January 17 2016 - February 18 2016</small></h4></li>
  <li class="list-group-item text-center "><button type="button" class="btn btn-success"><a href="views/events.php">View More</button></li>
</ul>
</div>
</div>
  <?php
    require 'footer.php';
     ?>