   <?php
require 'header.php';
 ?>
   <!-- <link rel="stylesheet" type="text/css" href="http://getbootstrap.com.vn/examples/equal-height-columns/equal-height-columns.css"> -->
    <style type="text/css">
      .cont {
        padding-top: 150px;
        background-color: #eee;
      }
        .myimg {
          max-width: 100%;
          
        }
    
    </style>
    <div class="container cont">
    
    <div class="row">
  <div class="col-xs-12 col-sm-12 col-md-8 col-lg-8">
  <h2 class="h2">FROM THE CLUBS AND SOCIETES DEPARTMENT</h2>
  <hr>
   <div>
  <p>Hogwarts high school, in line with our missions, to prepare and produce holistic young men to serve humanity and cognizant of the fact that it takes more than good grades to achieve its mission, takes clubs and societies very seriously.
</p>
</div>
<div>
  <p>In clubs and societies, students have an opportunity to interact and socialize with one another; teachers and resource person outside the formal class setting. Apart from attaining the specific club objectives, many students particularly those who take leadership positions sharpen their skills in human resource management.
     </p> 
   </div>
   <div>
     <p>
       We have many clubs and by using a five-star evaluation scale, where we have given them their rating accordingly. The criteria in patron engagement, leadership structure, regular organised meetings in and out of school activities, and existence of register members. (Refer to the clubs & societies segment for this rating.)
            </p>
            <p>
              
              We have two categories of clubs; A and B.A student is supposed to be a member of two clubs, one in each category. The two categories meet on alternate Wednesdays from 4pm to 5pm.each club has patrons who oversee elections of officials, set the mood of the club by outlining the terms activities, coordinating outings and visiting groups as well as selection and invitation of resource persons.
            </p>
            <p>
            We also have societies. These are the YCS, CU, Muslim students and the SDA. While to a large extent these societies are guided by the doctrines of their faith, we liaise with the students and their parents to select, regulate and operate the aspects of their spiritual nourishment which do not conflict with our broader institutional objectives. This has worked very well in the best interests of all concerned parties. Now that I am writing this report during the holy month of Ramadhan, I wish our Muslim students Ramadhan Kareem, Saum Makbul.
            </p>
          </div>
  </div>
  <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
     <a href="#" class="thumbnail">
      <img src="http://4.bp.blogspot.com/_rmT5UwXhQPE/S9W4OEqoeUI/AAAAAAAAADw/a2UQqj0J3OM/s1600/DSCF3267.JPG" alt="boarding department head" class="img-thumbnail img-responsive">
      <div class="caption">
        <h3>From the Department</h3>
        <p>Interacting in the community</p>
        </div>
    </a>
  </div>
</div>
</div>
    <?php
    require 'footer.php';
     ?>
    </body>
    </html>