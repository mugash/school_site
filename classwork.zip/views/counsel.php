   <?php
require 'header.php';
 ?>
   <!-- <link rel="stylesheet" type="text/css" href="http://getbootstrap.com.vn/examples/equal-height-columns/equal-height-columns.css" -->>
    <style type="text/css">
      .cont {
        padding-top: 150px;
        background-color: #eee;
        .myimg {
          width: 100%;
      }
    </style>
    <div class="container cont">
    
    <div class="row">
  <div class="col-md-8">
  <h2 class="h2">FROM THE CONSELLING AND GUIDANCE DEPARTMENT</h2>
  <hr>
   <div class="para1">
  <p>It’s yet another moment to share with you the goodness and success that our department has achieved since the last edition.
</p>
</div>
<div class="para2">
  <p>The department has worked has worked very closely with all students, teachers in all departments, the students council, the office of the deputy principal and all the principal to address various issues affecting our students. Serious and honest consultation has been taking place in all areas. This has enabled us to achieve the much success which we are proud of today.
     </p>
   </div>
   <div class="para3">
     <p>
       
            </p>
          </div>
  </div>
  <div class="col-md-4">
     <a href="#" class="thumbnail">
      <img src="http://www.eveshamjournal.co.uk/resources/images/3273769/" alt="boarding department head" class="img-thumbnail img-responsive">
      <div class="caption">
        <h3>The members</h3>
        <p>Department Members</p>
        </div>
    </a>
  </div>
</div>
</div>
    <?php
    require 'footer.php';
     ?>
    </body>
    </html>