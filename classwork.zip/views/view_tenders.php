<?php
require 'header.php';
 ?>
  <style type="text/css">
 	.push{
 		padding-top: 50px;
 	}
 		.text-info {
         color: #3498db!important;
 		}
 	
 </style>

 <div class="container text-center push">
 <div class="jumbotron">
 <h2>
                    <a class="text-info" href="#">High School Football Player Who Died Shielding Others From Gunfire Will Receive ESPY Courage Award</a>
                </h2>
                <p class="lead">
                    by <a class="text-info" href="index.php">Hogwart High</a>
                </p>
                <p><span class="glyphicon glyphicon-time"></span> Posted on August 28, 2015 at 10:00 PM</p>
                <hr>
                <img class="img-responsive" src="http://a.abcnews.com/images/US/HT_Zaevion_William_Dobson_mm_151218_3_12x5_1600.jpg" alt="">
                <hr>
                <p>The high student school football player who died in December while protecting three girls from gunfire will receive this year's Arthur Ashe Courage Award at the ESPYs tonight.Zaevion Dobson died while shielding three girls, who were unharmed, from shots when several men drove into his neighborhood and opened fire, according to Knoxville police. Police believed that the shootings were gang-related and that Dobson, 15, was not targeted.</p>
               <a href="#"> <button type="button" class="btn btn-primary">Apply</button>
                </div>
                </div>
  <?php
    require 'footer.php';
     ?>