<?php
	require 'header.php';
?>
<html>
<head>
	<title>
	</title>
</head>
<body>
	<p>
	<div class="container jumbotron">
		<div class="well row">
			<div class="content-wrapper page-content-wrapper clearfix col-lg-8">
				<div class="inner-content-wrapper">
					<p style="text-align: center;">
						<strong>
							K.C.S.E 2015 Results,
						</strong>
					</p>
						<p style="text-align: center;">
							<strong>
								Our first national class of 2015 posted an impressive mean of 9.58. 
							</strong>
						</p>
					<p>
						<a href="../assests/image/examright.jpg" rel="attachment wp-att-1918">
							<img  src="../assests/image/examright.jpg" sizes="(max-width: 960px) 100vw, 960px" />
						</a>
					</p>
				</div>
			</div>
		</div>
	</div>
	</p>
</body>
</html>
<?php
	require 'footer.php';
?>