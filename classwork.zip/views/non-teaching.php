<?php
require 'header.php';
 ?>

    <!-- Page Content -->
    <!-- <link rel="stylesheet" type="text/css" href="http://getbootstrap.com.vn/examples/equal-height-columns/equal-height-columns.css"> -->
    <style>
  .thumb {
    padding-top: 150px;
    background-color: #eee;
     margin-bottom: 30px;
  }
    </style>

    <div class="container thumb">
    <h2>The teaching Staff</h2>

        <div class="row">

              
            
            <div class="col-lg-3 col-md-3 col-xs-6 thumb">
                <a class="thumbnail" href="#">
                    <img class="img-responsive" src="http://www.dusablemuseum.org/dsmcms/expressionengine/cache/9305640d715f66e494660f2cdcbdc38bf7b6b87a.jpg" alt="">
                    <div class="caption">
       <h3>Pro. Targeryn</h3>
       <p>
         Non-staff member</p>
       </div>
                </a>
            </div>
            <div class="col-lg-3 col-md-3 col-xs-6 thumb">
                <a class="thumbnail" href="#">
                    <img class="img-responsive" src="http://www.dusablemuseum.org/dsmcms/expressionengine/cache/9305640d715f66e494660f2cdcbdc38bf7b6b87a.jpg" alt="">
                    <div class="caption">
       <h3>Mr.Mbeki</h3>
       <p>
        Non-teaching staff</p>
       </div>
                </a>
            </div>
            <div class="col-lg-3 col-md-3 col-xs-6 thumb">
                <a class="thumbnail" href="#">
                    <img class="img-responsive" src="http://www.dusablemuseum.org/dsmcms/expressionengine/cache/9305640d715f66e494660f2cdcbdc38bf7b6b87a.jpg" alt="">
                    <div class="caption">
       <h3>Mr.Simba</h3>
       <p>
         Non-staff member</p>
       </div>
                </a>
            </div>
            <div class="row">
            <div class="col-lg-3 col-md-3 col-xs-6 thumb">
                <a class="thumbnail" href="#">
                    <img class="img-responsive" src="http://www.dusablemuseum.org/dsmcms/expressionengine/cache/9305640d715f66e494660f2cdcbdc38bf7b6b87a.jpg" alt="">
                    <div class="caption">
       <h3>Mr.Simba</h3>
       <p>
         Non-staff member</p>
       </div>
                </a>
            </div>
            <div class="col-lg-3 col-md-3 col-xs-6 thumb">
                <a class="thumbnail" href="#">
                    <img class="img-responsive" src="http://www.dusablemuseum.org/dsmcms/expressionengine/cache/9305640d715f66e494660f2cdcbdc38bf7b6b87a.jpg" alt="">
                    <div class="caption">
       <h3>Mr.Simba</h3>
       <p>
         Non-staff member</p>
       </div>
                </a>
            </div>
            <div class="col-lg-3 col-md-3 col-xs-6 thumb">
                <a class="thumbnail" href="#">
                    <img class="img-responsive" src="http://www.dusablemuseum.org/dsmcms/expressionengine/cache/9305640d715f66e494660f2cdcbdc38bf7b6b87a.jpg" alt="">
                    <div class="caption">
       <h3>Mr.Simba</h3>
       <p>
         Non-staff member</p>
       </div>
                </a>
            </div>
                <div class="col-lg-3 col-md-3 col-xs-6 thumb">
                <a class="thumbnail" href="#">
                    <img class="img-responsive" src="http://www.dusablemuseum.org/dsmcms/expressionengine/cache/9305640d715f66e494660f2cdcbdc38bf7b6b87a.jpg" alt="">
                    <div class="caption">
       <h3>Mrs.Jane</h3>
       <p>
         Non-staff member</p>
       </div>
                </a>
            </div>
                <div class="col-lg-3 col-md-3 col-xs-6 thumb">
                <a class="thumbnail" href="#">
                    <img class="img-responsive" src="http://www.dusablemuseum.org/dsmcms/expressionengine/cache/9305640d715f66e494660f2cdcbdc38bf7b6b87a.jpg" alt="">
                    <div class="caption">
       <h3>Mrs.Jane</h3>
       <p>
         Non-staff member </p>
       </div>
                </a>
            </div>
            </div>
            </div>

      </div>
      </div>
        
        <?php
    require 'footer.php';
     ?>
        </body>
    </html>
