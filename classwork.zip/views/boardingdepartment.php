   <?php
require 'header.php';
 ?>
 <!--   <link rel="stylesheet" type="text/css" href="http://getbootstrap.com.vn/examples/equal-height-columns/equal-height-columns.css"> -->
    <style type="text/css">
      .cont {
        padding-top: 150px;
        background-color: #eee;flood-color: }
        .myimg {
          width: 100%;
        
      }
    </style>
    <div class="container cont">
    
    <div class="row">
  <div class="col-xs-12 col-sm-12 col-md-8 col-lg-8">
  <h2 class="h2">FROM THE BOARDING DEPARTMENT DEPARTMENT</h2>
  <hr class="star-primary">
  <p>
   The provision of the basic services to learners is an important and integral part in boarding school. On our part in Hogwarts high school, we are doing the best we can towards this end. Consequently water supply and diet have been improved. Further, to decongest the dormitories a new dormitory has been commission. To protect the boys from influence and interference from outside, the school has been fenced. I do believe that our boys will seize upon these obvious advantages to work harder for an academic success which is the main if not the only reason they are in this school. As teachers in the boarding department we would like to encourage the boys to work hard to realize success. We wish them the best. Boys, may god bless you not only bless – but bless abundantly. Amen.
   </p>
  </div>
  <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
     <a href="#" class="thumbnail">
      <img src="http://www.princehenrys.worcs.sch.uk/wp-content/uploads/2015/09/20150909-SLT-1-crop.jpg" alt="boarding department head" class="img-thumbnail img-responsive">
      <div class="caption">
        <h3>The members</h3>
        <p>Boarding Department</p>
        </div>
    </a>
  </div>
</div>
</div>
    <?php
    require 'footer.php';
     ?>
    </body>
    </html>
