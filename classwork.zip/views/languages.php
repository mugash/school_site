   <?php
require 'header.php';
 ?>
   <!-- <link rel="stylesheet" type="text/css" href="http://getbootstrap.com.vn/examples/equal-height-columns/equal-height-columns.css" -->>
    <style type="text/css">
      .cont {
        padding-top: 150px;
        background-color: #eee;
      }
        .myimg {
          width: 100%;
        }
      
    </style>
    <div class="container cont">
    
    <div class="row">
  <div class="col-xs-12 col-sm-12 col-md-8 col-lg-8">
  <h2 class="h2">FROM THE LANGUAGES DEPARTMENT</h2>
  <hr>
   <div class="para1">
  <p>Its great privilege to have the opportunity to share with you achievements and challenges that we have gone through since the publishing of the previous issue of EYE OPENER
</p>
</div>
<div class="para2">
  <p>There are two subjects under these departments English and Kiswahili. The 2 subjects are considered core subjects because they are compulsory and every student must take them in the four years they are in school.
     </p>
   </div>
   <div class="para3">
     <p>
       In the last years’ KCSE, there was notable improvement in Kiswahili while there was a drop in English nationally, and we were no exception.
            </p>
            <p>

            Due to the emmerging challenges, we have come up with strategies to steer up towards improved performances in both languages. We have put in place strategies that will without doubt bear fruits and play a significant role in the realization of the school overall target this year.
            </p>
            <p>
              These include:-

Setting standard exams that reflect content stipulated by both KNEC and KICD. This will prepare students for the final exams and also equip them with the skills that assist them in their day to day life (Practical skills in speech making)
Harmonized assessment. Satisfactory conditions for both testing and assessment are set by teachers to ensure a standardized procedure that does not advantage or disadvantage a certain group of students.
Keeping of records of assessment for monitoring students’ progress. This assist in the change of approach should a student not show improvement within given time.
Holding departmental meeting during which there is evaluation of the procedures that guide teachers and students in their performance.
Team teaching. The department encourages teacher’s team build through class exchange programme in both teaching and evaluation.
We hope with the above strategies we are going to do better than last year in this year KCSE.

            </p>
          </div>
  </div>
  <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
     <a href="#" class="thumbnail">
      <img src="hum.jpg" alt="boarding department head" class="img-thumbnail img-responsive">
      <div class="caption">
        <h3>Mr.Kaluma</h3>
        <p>Department Chairman</p>
        </div>
    </a>
  </div>
</div>
</div>
    <?php
    require 'footer.php';
     ?>
    </body>
    </html>