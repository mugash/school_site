   <?php
require 'header.php';
 ?>
   <!-- <link rel="stylesheet" type="text/css" href="http://getbootstrap.com.vn/examples/equal-height-columns/equal-height-columns.css"> -->
    <style type="text/css">
      .cont {
        padding-top: 150px;
        background-color: #eee;
      }
        .myimg {
          width: 100%;
        
      }
    </style>
    <div class="container cont">
    
    <div class="row">
  <div class="col-xs-12 col-sm-12 col-md-8 col-lg-8">
  <h2 class="h2">FROM THE MATHEMATICS DEPARTMENT</h2>
  <hr>
   <div class="para1">
  <p>The department of mathematics celebrates victory for the year 2013 KCSE candidates. The best results ever were realized. The boys managed a mean score of 9.7592 up from 9.392, a positive deviation of +0.3672. Out of 245 students 129 scored A and A- grades. Grades A plain was mode with frequency of 94 students. The department managed to completely eliminate D- and E.
</p>
</div>
<div class="para2">
  <p>The department took the lead in quality grades and in output. Congratulations to the 2013 candidates for placing the department at that level. The challenge is now to the 2014 candidates. The department believes that we can maintain the wondrous performance and improve on the same. We are focused on the school target mean score of 10.5 or above. God enabling us we will be there. Measures are in place to realize the big dream of attaining 200 A’s and A- (Minus). We believe in excellent discipline, proper time management and perfect practice in mathematics, clearance of the syllabus early as March is one of the key indicators that will make it. The department says aloud, “Do it can be done.” I steering the department high and higher. I also thank the principal for his continued support to the department. May god grant us the desires of our hearts in the department.
     </p>
   </div>
  </div>
  <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
     <a href="#" class="thumbnail">
      <img src="http://news.images.itv.com/image/file/746097/stream_img.jpg" alt="boarding department head" class="img-thumbnail img-responsive">
      <div class="caption">
        <h3>From the Department</h3>
        <p>Student after the mathematics contest</p>
        </div>
    </a>
  </div>
</div>
</div>
    <?php
    require 'footer.php';
     ?>
    </body>
    </html>