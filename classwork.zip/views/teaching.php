<?php
require 'header.php';
 ?>

    <!-- Page Content -->
    <!-- <link rel="stylesheet" type="text/css" href="http://getbootstrap.com.vn/examples/equal-height-columns/equal-height-columns.css"> -->
    <style>
  .thumb {
    padding-top: 150px;
    background-color: #eee;
     margin-bottom: 30px;
  }
    </style>

    <div class="container thumb">
    <h2>The Teaching Staff</h2>

        <div class="row">

              
            
            <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4 thumb">
                <a class="thumbnail" href="#">
                    <img class="img-responsive" src="http://www.princehenrys.worcs.sch.uk/wp-content/uploads/2013/09/Headboy_HeadGirl-1024x682.jpg" alt="">
                    <div class="caption">
       <h3>Mr.simba</h3>
       <p>English Teacher</p>
       </div>
                </a>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4 thumb">
                <a class="thumbnail" href="#">
                    <img class="img-responsive" src="http://www.therotaryclubofevesham.org.uk/media/images/BTG_2015_9.JPG" alt="">
                    <div class="caption">
       <h3>Mr.Mbeki</h3>
       <p>
        The Principal</p>
       </div>
                </a>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4 thumb">
                <a class="thumbnail" href="#">
                    <img class="img-responsive" src="http://www.therotaryclubofevesham.org.uk/media/images/BTG_2015_9.JPG" alt="">
                    <div class="caption">
       <h3>Mr.Kasimba</h3>
       <p>
         The French teacher </p>
       </div>
                </a>
            </div>
            </div>
            <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4 thumb">
                <a class="thumbnail" href="#">
                    <img class="img-responsive" src="http://www.dusablemuseum.org/dsmcms/expressionengine/cache/9305640d715f66e494660f2cdcbdc38bf7b6b87a.jpg" alt="">
                    <div class="caption">
       <h3>Mr.Simba</h3>
       <p>
         Chairman </p>
       </div>
                </a>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4 thumb">
                <a class="thumbnail" href="#">
                    <img class="img-responsive" src="http://www.dusablemuseum.org/dsmcms/expressionengine/cache/9305640d715f66e494660f2cdcbdc38bf7b6b87a.jpg" alt="">
                    <div class="caption">
       <h3>Mr.Simba</h3>
       <p>
         Chairman </p>
       </div>
                </a>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4 thumb">
                <a class="thumbnail" href="#">
                    <img class="img-responsive" src="http://www.dusablemuseum.org/dsmcms/expressionengine/cache/9305640d715f66e494660f2cdcbdc38bf7b6b87a.jpg" alt="">
                    <div class="caption">
       <h3>Mr.Simba</h3>
       <p>
         Chairman </p>
       </div>
                </a>
            </div>
            </div>
            <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4 thumb">
                <a class="thumbnail" href="#">
                    <img class="img-responsive" src="http://www.dusablemuseum.org/dsmcms/expressionengine/cache/9305640d715f66e494660f2cdcbdc38bf7b6b87a.jpg" alt="">
                    <div class="caption">
       <h3>Mr.Simba</h3>
       <p>
         Chairman </p>
       </div>
                </a>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4 thumb">
                <a class="thumbnail" href="#">
                    <img class="img-responsive" src="http://www.dusablemuseum.org/dsmcms/expressionengine/cache/9305640d715f66e494660f2cdcbdc38bf7b6b87a.jpg" alt="">
                    <div class="caption">
       <h3>Mr.Simba</h3>
       <p>
         Chairman </p>
       </div>
                </a>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4 thumb">
                <a class="thumbnail" href="#">
                    <img class="img-responsive" src="http://www.dusablemuseum.org/dsmcms/expressionengine/cache/9305640d715f66e494660f2cdcbdc38bf7b6b87a.jpg" alt="">
                    <div class="caption">
       <h3>Mr.Simba</h3>
       <p>
         Chairman </p>
       </div>
                </a>
            </div>
            </div>
            </div>
            </div>

      </div>
      </div>
        
        <?php
    require 'footer.php';
     ?>
        </body>
    </html>
