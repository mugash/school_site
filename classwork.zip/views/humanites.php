   <?php
require 'header.php';
 ?>
  <!--  <link rel="stylesheet" type="text/css" href="http://getbootstrap.com.vn/examples/equal-height-columns/equal-height-columns.css"> -->
    <style type="text/css">
      .cont {
        padding-top: 150px;
        background-color: #eee;
        .myimg {
          width: 100%;
        
      }
    </style>
    <div class="container cont">
    
    <div class="row">
  <div class="col-xs-12 col-sm-12 col-md-8 col-lg-8">
  <h2 class="h2">FROM THE HUMANITIES DEPARTMENT</h2>
  <hr>
   <div class="para1">
  <p>Am happy to report in this years’ edition of the school magazine that the department is now set to overhaul the age old traditions of doing things the same way. The reason is we want to see change and transformation in the department which we belief has power to change the mean score if we achieve our dreams.

.
</p>
</div>
<div class="para2">
  <p>We’ve laid down strategies to change the stagnant mean score 9 and about to above the school target mean of 10.5+
     </p>
   </div>
   <div class="para3">
     <p>
    With energy injected in by the five new members who joined the department this year, we from a strong team that is determined to realize the big dream of excellence in our school.
            </p>
          </div>
          <p>
          Reorganization in the areas of effective content delivery as displayed by passion and motivation among the teachers, change of attitude among students, discipline and evaluation methods, we are ready to take the lead in the school and also country wide.

</p>
<p>
The department continues to equip the learners with knowledge and skills in various disciplines.
</p>
<p>
History deals with the past, current and then basing on that firm foundation, critical analysis is done to the discoveries and achievements by man. Then we are able to the project to the future.
</p>
<p>

Geography explains the great wonders displayed by a great designer who shaped the universe in His wisdom
</p>
  </div>
  <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
     <a href="#" class="thumbnail">
      <img src="http://www.cotswoldjournal.co.uk/resources/images/3216976/" alt="boarding department head" class="img-thumbnail img-responsive">
      <div class="caption">
        <h3>From the department</h3>
        <p>The students after Competition</p>
        </div>
    </a>
  </div>
</div>
</div>
    <?php
    require 'footer.php';
     ?>
    </body>
    </html>