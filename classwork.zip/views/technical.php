   <?php
require 'header.php';
 ?>
  <!--  <link rel="stylesheet" type="text/css" href="http://getbootstrap.com.vn/examples/equal-height-columns/equal-height-columns.css"> -->
    <style type="text/css">
      .cont {
        padding-top: 150px;
        background-color: #eee;
      }
        .myimg {
          width: 100%;
        
      }
    </style>
    <div class="container cont">
    
    <div class="row">
  <div class="col-xs-12 col-sm-12 col-md-8 col-lg-8">
  <h2 class="h2">FROM THE TECHNICAL AND CREATIVE ARTS DEPARTMENT</h2>
  <hr>
   <div class="para1">
  <p>Thank you EYE OPENER for allowing us gives a report concerns this department. As a department we wish to thank the almighty god for his blessing s and favour experienced this far.


</p>
<p>
The students have shown themselves to be able young men, highly committed in their studies and diligent in the subject choices they make in both form 1 and three. Keep it up boys, bearing in mind the choices you make now will impact on your future.
</p>
</div>
<div class="para2">
  <p>
    This goal has been achieved consistently by the dedicated and highly experienced staffs who have utilized the power of synergy through display of a rare breed of team work. Thank you members, you are rare species that any leader would yearn to work with.
     </p>
   </div>
   <div class="para3">
     <p>
       The school administration has given us the necessary support through provision of teaching and learning materials and a conducive learning environment.

We are sincerely thankful.

            </p>
          </div>
  </div>
  <div class="col-md-4">
     <a href="#" class="thumbnail">
      <img src="http://www.herefordtimes.com/resources/images/2602081.jpg?type=articleLandscape" alt="boarding department head" class="img-thumbnail img-responsive">
      <div class="caption">
        <h3>From the department</h3>
        <p>Student taking a French class</p>
        </div>
    </a>
  </div>
</div>
</div>
    <?php
    require 'footer.php';
     ?>
    </body>
    </html>