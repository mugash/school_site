<?php
	require '../models/model.php';
	echo json_encode(get_all_news($b));
?>