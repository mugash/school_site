<?php
	require '../models/model.php';
	echo json_encode(get_staff($b));
?>