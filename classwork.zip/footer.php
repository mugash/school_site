<style type="text/css">
    footer {
        background-color: ;
    }
</style>

</div>
<footer class="footer-distributed" style="background-color: #2c3e50;">

  <div class="footer-left">

    <a href="index.php"><h3><span>HOGWARTS</span> HIGH</h3></a>

    <p class="footer-links">
      <a href="index.php">Home</a>
      .
      <a href="#">About Our School</a>
      ·
      <a href="#">Departments</a>
      ·
      <a href="#">Students</a>
      <a href="views/contact.php">Contact Us</a>
    </p>

    <p class="footer-company-name">Hogwarts High &copy; 2016</p>
  </div>

  <div class="footer-center">

    <div>
      <i class="fa fa-map-marker"></i>
      <p><span>61,71900</span> Nyeri, Kenya</p>
    </div>

    <div>
      <i class="fa fa-phone"></i>
      <p>+254 727-021-846</p>
    </div>

    <div>
      <i class="fa fa-envelope"></i>
      <p><a href="mailto:support@hogwartshigh.ac.ke">support@hogwartshigh.ac.ke</a></p>
    </div>

  </div>

  <div class="footer-right">

    <p class="footer-company-about">
      <span>About Our School</span>
     Hogwarts high school is a one of a kind high school with a mission of empowering the society by creating wholistic and all round individuals helpfull to both themselves and the society.</p>

    <div class="footer-icons">

      <a href="#"><i class="fa fa-facebook"></i></a>
      <a href="#"><i class="fa fa-twitter"></i></a>


    </div>

  </div>

</footer>
<!-- jQuery -->
<script src="assests/js/jquery-1.12.3.min.js"></script>
<script src="../assests/js/jquery-1.12.3.min.js"></script>

<!-- Bootstrap Core JavaScript -->
<script src="assests/js/bootstrap.min.js"></script>
<script>
$('nav li').hover(
  function() {
    $('ul', this).stop().slideDown(200);
  },
  function() {
    $('ul', this).stop().slideUp(200);
  }
);
</script>
